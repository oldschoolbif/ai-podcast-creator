"""GUI interfaces for AI Podcast Creator"""
