"""Database models for AI Podcast Creator"""
