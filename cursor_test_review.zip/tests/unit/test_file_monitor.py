import time
from pathlib import Path

import pytest

from src.utils.file_monitor import FileMonitor


def test_file_monitor_tracks_growth(tmp_path):
    file_path = tmp_path / "growing.bin"
    updates = []

    monitor = FileMonitor(
        file_path,
        update_callback=lambda size, rate, warning: updates.append((size, rate, warning)),
        check_interval=0.01,
    )

    monitor.start()
    # Give monitor loop time to start
    time.sleep(0.02)

    with file_path.open("wb") as f:
        f.write(b"\x00" * (512 * 1024))

    time.sleep(0.03)

    with file_path.open("ab") as f:
        f.write(b"\x00" * (256 * 1024))

    time.sleep(0.05)
    monitor.stop()

    summary = monitor.get_metrics_summary()
    assert summary["final_size_mb"] == pytest.approx(0.75, rel=0.2)
    assert summary["average_growth_rate_mb_per_sec"] >= 0
    assert summary["growth_samples_count"] >= 0
    # At least one callback should have triggered once file existed
    assert any(entry[0] >= 0 for entry in updates)


def test_file_monitor_helpers(tmp_path):
    file_path = tmp_path / "file.bin"
    file_path.write_bytes(b"\x00" * 128)

    monitor = FileMonitor(file_path)
    # Manually tweak internal counters
    monitor.stall_time = monitor.stall_threshold
    assert monitor.is_stalled()

    assert monitor.get_current_size_mb() == pytest.approx(0.000122, rel=0.1)
    monitor.growth_samples = [0.5, 1.0, 0.75]
    assert monitor.get_average_growth_rate() == pytest.approx(0.75)

    monitor.stop()
    metrics = monitor.get_metrics_summary()
    assert "file_creation_time_sec" in metrics
    assert metrics["final_size_mb"] == pytest.approx(0.000122, rel=0.1)

