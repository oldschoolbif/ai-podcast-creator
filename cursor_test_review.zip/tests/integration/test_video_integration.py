"""
Integration tests for video composition - Test REAL video workflows
FIXED VERSION with correct moviepy mocking
"""

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.core.video_composer import VideoComposer
from tests.conftest import create_valid_mp3_file


def create_moviepy_mock(audio_duration=5.0):
    """Helper to create moviepy mock with sys.modules patch."""
    mock_audio = MagicMock()
    mock_audio.duration = audio_duration
    mock_audio.close = MagicMock()

    mock_video = MagicMock()
    mock_video.set_audio = MagicMock(return_value=mock_video)
    mock_video.set_duration = MagicMock(return_value=mock_video)
    mock_video.write_videofile = MagicMock()
    mock_video.close = MagicMock()

    mock_moviepy = MagicMock()
    mock_moviepy.editor = MagicMock()
    mock_moviepy.editor.AudioFileClip = MagicMock(return_value=mock_audio)
    mock_moviepy.editor.ImageClip = MagicMock(return_value=mock_video)
    mock_moviepy.editor.ColorClip = MagicMock(return_value=mock_video)
    mock_moviepy.editor.CompositeVideoClip = MagicMock(return_value=mock_video)

    return mock_moviepy, mock_audio, mock_video


@pytest.mark.integration
class TestVideoCompositionIntegration:
    """Integration tests for video composition."""

    def test_basic_video_composition(self, test_config, temp_dir):
        """Test basic video composition workflow."""
        test_config["storage"]["outputs_dir"] = str(temp_dir)
        test_config["video"] = {
            "resolution": [1280, 720],
            "fps": 30,
            "codec": "libx264",
            "background_path": str(temp_dir / "bg.jpg"),
        }

        audio_file = temp_dir / "test_audio.mp3"
        # Create valid MP3 file for happy path test
        create_valid_mp3_file(audio_file, duration_seconds=10.0)

        composer = VideoComposer(test_config)

        with (
            patch.object(VideoComposer, "_validate_audio_file", return_value=(True, "")),
            patch.object(VideoComposer, "_compose_minimal_video") as mock_minimal,
        ):
            mock_minimal.return_value = temp_dir / "integration_test.mp4"
            output = composer.compose(audio_file, output_name="integration_test")

            assert output.suffix == ".mp4"
            assert "integration_test" in str(output)
            assert output.parent == temp_dir
            mock_minimal.assert_called_once()
            # Note: validation happens inside _compose_minimal_video, which is mocked

    def test_custom_resolution_workflow(self, test_config, temp_dir):
        """Test different resolutions are handled correctly."""
        test_config["storage"]["outputs_dir"] = str(temp_dir)

        resolutions = [
            ([640, 480], "480p"),
            ([1280, 720], "720p"),
            ([1920, 1080], "1080p"),
        ]

        audio_file = temp_dir / "audio.mp3"
        # Create valid MP3 file for happy path test
        create_valid_mp3_file(audio_file, duration_seconds=5.0)

        for resolution, name in resolutions:
            test_config["video"] = {"resolution": resolution, "background_path": str(temp_dir / "bg.jpg")}
            composer = VideoComposer(test_config)

            mock_moviepy, mock_audio, mock_video = create_moviepy_mock()

            with (
                patch.dict("sys.modules", {"moviepy": mock_moviepy, "moviepy.editor": mock_moviepy.editor}),
                patch.object(VideoComposer, "_validate_audio_file", return_value=(True, "")),
            ):
                output = composer.compose(audio_file, output_name=name)

                # Verify resolution was used
                if mock_moviepy.editor.ColorClip.called:
                    call_kwargs = mock_moviepy.editor.ColorClip.call_args[1]
                    assert call_kwargs["size"] == resolution
                assert name in str(output)

    @pytest.mark.skipif(sys.version_info >= (3, 12), reason="Dynamic import patching issue in Python 3.12+")
    def test_visualization_workflow(self, test_config, temp_dir):
        """Test visualization generation workflow."""
        test_config["storage"]["outputs_dir"] = str(temp_dir)

        audio_file = temp_dir / "audio.mp3"
        # Create valid MP3 file for happy path test
        create_valid_mp3_file(audio_file, duration_seconds=5.0)

        expected_output = temp_dir / "viz_output.mp4"

        mock_visualizer = MagicMock()
        mock_visualizer.generate_visualization.return_value = expected_output

        with patch("src.core.audio_visualizer.AudioVisualizer", return_value=mock_visualizer):
            composer = VideoComposer(test_config)
            result = composer.compose(audio_file, use_visualization=True)

            mock_visualizer.generate_visualization.assert_called_once()
            assert result == expected_output

    def test_background_image_workflow(self, test_config, temp_dir):
        """Test using custom background image."""
        test_config["storage"]["outputs_dir"] = str(temp_dir)

        bg_file = temp_dir / "background.jpg"
        bg_file.write_bytes(b"fake image data")
        test_config["video"] = {"background_path": str(bg_file)}

        audio_file = temp_dir / "audio.mp3"
        # Create valid MP3 file for happy path test
        create_valid_mp3_file(audio_file, duration_seconds=3.0)

        composer = VideoComposer(test_config)

        with (
            patch.object(VideoComposer, "_validate_audio_file", return_value=(True, "")),
            patch.object(VideoComposer, "_compose_with_ffmpeg") as mock_ffmpeg,
        ):
            mock_ffmpeg.return_value = temp_dir / "output.mp4"
            output = composer.compose(audio_file, use_background=True)

            # Verify _compose_with_ffmpeg was called (background image path)
            mock_ffmpeg.assert_called_once()
            # Output should be created
            assert output is not None

    def test_audio_duration_handling(self, test_config, temp_dir):
        """Test different audio durations."""
        test_config["storage"]["outputs_dir"] = str(temp_dir)
        test_config["video"] = {"background_path": str(temp_dir / "bg.jpg")}

        audio_file = temp_dir / "audio.mp3"
        # Create valid MP3 file for happy path test
        create_valid_mp3_file(audio_file, duration_seconds=5.0)

        durations = [1.0, 5.0, 30.0, 120.0]

        for duration in durations:
            composer = VideoComposer(test_config)

            with (
                patch.object(VideoComposer, "_validate_audio_file", return_value=(True, "")),
                patch.object(VideoComposer, "_compose_with_ffmpeg") as mock_ffmpeg,
            ):
                mock_ffmpeg.return_value = temp_dir / f"test_{duration}s.mp4"
                output = composer.compose(audio_file, output_name=f"test_{duration}s", use_background=True)

                # Verify _compose_with_ffmpeg was called (background image path)
                mock_ffmpeg.assert_called_once()
                assert f"test_{duration}s" in str(output)

    def test_output_directory_creation(self, test_config, temp_dir):
        """Test output directory is created if missing."""
        output_dir = temp_dir / "videos" / "nested" / "path"
        test_config["storage"]["outputs_dir"] = str(output_dir)
        test_config["video"] = {"background_path": str(temp_dir / "bg.jpg")}

        assert not output_dir.exists()

        composer = VideoComposer(test_config)

        assert output_dir.exists()
        assert composer.output_dir == output_dir

    def test_timestamp_generation(self, test_config, temp_dir):
        """Test automatic timestamp in filename."""
        test_config["storage"]["outputs_dir"] = str(temp_dir)
        test_config["video"] = {"background_path": str(temp_dir / "bg.jpg")}

        audio_file = temp_dir / "audio.mp3"
        # Create valid MP3 file for happy path test
        create_valid_mp3_file(audio_file, duration_seconds=5.0)

        composer = VideoComposer(test_config)

        mock_moviepy, mock_audio, mock_video = create_moviepy_mock()

        with (
            patch.dict("sys.modules", {"moviepy": mock_moviepy, "moviepy.editor": mock_moviepy.editor}),
            patch.object(VideoComposer, "_validate_audio_file", return_value=(True, "")),
        ):
            output1 = composer.compose(audio_file, output_name=None)
            output2 = composer.compose(audio_file, output_name=None)

            assert "podcast_" in str(output1)
            assert "podcast_" in str(output2)

    def test_error_handling_missing_audio(self, test_config, temp_dir):
        """Test error handling for missing audio file."""
        test_config["storage"]["outputs_dir"] = str(temp_dir)
        test_config["video"] = {"background_path": str(temp_dir / "bg.jpg")}

        missing_file = temp_dir / "nonexistent.mp3"

        composer = VideoComposer(test_config)

        # Should raise ValueError from validation (not FileNotFoundError)
        with pytest.raises(ValueError) as exc_info:
            composer.compose(missing_file)
        
        # Verify error message mentions the file doesn't exist
        assert "does not exist" in str(exc_info.value).lower() or "Audio file" in str(exc_info.value)
    
    def test_error_handling_corrupted_mp3(self, test_config, temp_dir):
        """Test graceful error handling with corrupted MP3 file."""
        test_config["storage"]["outputs_dir"] = str(temp_dir)
        test_config["video"] = {"background_path": str(temp_dir / "bg.jpg")}

        # Create a corrupted MP3 file (invalid MP3 structure)
        corrupted_file = temp_dir / "corrupted.mp3"
        # Write invalid data that looks like it might be an MP3 but isn't
        corrupted_file.write_bytes(b"FAKE_MP3_DATA" * 20)  # 260 bytes - passes size check but invalid format

        composer = VideoComposer(test_config)

        # Should raise ValueError or RuntimeError with clear error message
        with pytest.raises((ValueError, RuntimeError)) as exc_info:
            composer.compose(corrupted_file, output_name="corrupted_test")
        
        error_msg = str(exc_info.value)
        # Verify error message is helpful for troubleshooting
        assert ("validation" in error_msg.lower() or 
                "corrupted" in error_msg.lower() or
                "invalid" in error_msg.lower() or
                "ffmpeg" in error_msg.lower())
        assert str(corrupted_file) in error_msg
        # Should provide troubleshooting information
        assert "Troubleshooting" in error_msg or "troubleshooting" in error_msg.lower()
    
    def test_error_handling_empty_mp3(self, test_config, temp_dir):
        """Test graceful error handling with empty MP3 file."""
        test_config["storage"]["outputs_dir"] = str(temp_dir)
        test_config["video"] = {"background_path": str(temp_dir / "bg.jpg")}

        # Create an empty file
        empty_file = temp_dir / "empty.mp3"
        empty_file.write_bytes(b"")

        composer = VideoComposer(test_config)

        # Should raise ValueError with clear error message
        with pytest.raises(ValueError) as exc_info:
            composer.compose(empty_file, output_name="empty_test")
        
        error_msg = str(exc_info.value)
        assert ("empty" in error_msg.lower() or 
                "too small" in error_msg.lower() or
                "validation" in error_msg.lower())
        assert str(empty_file) in error_msg


@pytest.mark.integration
class TestVideoAvatarIntegration:
    """Integration tests for avatar video workflows."""

    def test_avatar_with_visualization_overlay(self, test_config, temp_dir):
        """Test overlaying visualization on avatar video."""
        test_config["storage"]["outputs_dir"] = str(temp_dir)
        test_config["video"] = {"background_path": str(temp_dir / "bg.jpg")}

        audio_file = temp_dir / "audio.mp3"
        avatar_video = temp_dir / "avatar.mp4"
        # Create valid MP3 file for happy path test
        create_valid_mp3_file(audio_file, duration_seconds=5.0)
        avatar_video.write_bytes(b"video")

        output_file = temp_dir / "final.mp4"

        with patch.object(VideoComposer, "_overlay_visualization_on_avatar", return_value=output_file):
            composer = VideoComposer(test_config)
            result = composer.compose(audio_file, avatar_video=avatar_video, use_visualization=True)

            assert result == output_file
