Param(
    [string]$MutmutArgs = ""
)

Write-Host "🐳 Launching Linux container for mutmut..." -ForegroundColor Cyan

$dockerImage = "aipodcast-mutmut-gpu:latest"
$dockerfilePath = "docker/MutmutGpu.Dockerfile"

function Test-DockerImageExists {
    param([string]$ImageName)
    $exists = $false
    try {
        docker image inspect $ImageName *> $null
        $exists = $true
    } catch {
        $exists = $false
    }
    return $exists
}

if (-not (Test-DockerImageExists -ImageName $dockerImage)) {
    Write-Host "🔧 Building GPU-enabled mutmut image ($dockerImage)..." -ForegroundColor Yellow
    docker build -t $dockerImage -f $dockerfilePath .
}

$useGpu = $true
if ($env:MUTMUT_USE_GPU -eq "0") {
    $useGpu = $false
}

$bashCommands = @(
    "set -e",
    "export PYDUB_AUDIO_CONVERTER=ffmpeg",
    "python -m venv /tmp/mutenv",
    "source /tmp/mutenv/bin/activate",
    "python -m pip install --upgrade --quiet pip setuptools wheel",
    "pip install --quiet -r requirements-mutation.txt",
    "pip install --quiet -r requirements-dev.txt",
    "pip install --quiet --extra-index-url https://download.pytorch.org/whl/cu121 torch==2.5.1+cu121 torchvision==0.20.1+cu121 torchaudio==2.5.1+cu121",
    "python -m mutmut run $MutmutArgs",
    "python -m mutmut results"
) -join " && "

$dockerArgs = @("--rm")
if ($useGpu) {
    $dockerArgs += "--gpus"
    $dockerArgs += "all"
}
$dockerArgs += @(
    "-v", "${PWD}:/workspace",
    "-w", "/workspace",
    $dockerImage,
    "bash",
    "-lc",
    $bashCommands
)

docker run @dockerArgs

if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Mutation testing finished (results above)." -ForegroundColor Green
} else {
    Write-Host "❌ Mutmut exited with code $LASTEXITCODE." -ForegroundColor Red
    exit $LASTEXITCODE
}
